# pense.stt module
